#include<graphics.h>
#include "Fenetres.h"
#include "Figure.h"
#include <iostream>
#include<math.h>
#include "Dessin.h"
using namespace std;

main()
{
	
	int x,y,type,longueur,hauteur,couleur;
 Fenetres f;
 Figure g;
 Dessin bonHomme;
 cout<<"donner la couleur avec laquelle vous voullez dessiner"<<endl;
 cin>>couleur;
 if(couleur<0|| couleur>15)
 couleur=3;
 cout<<"donner l'abscisse x du centre de votre figure"<<endl;
 cin>>x;
 cout<<"donner l'ordonnee y du centre de votre figure"<<endl;
 cin>>y;
 
cout<<"donner un nombre de 1 a 7 : "<<endl;
cout<<"  1: droite horizontale"<<endl;
cout<<"  2: droite verticale "<<endl;
cout<<"  3: droite inclinee"<<endl;
cout<<"  4: cercle"<<endl;
cout<<"  5: rectangle"<<endl;
cout<<"  6: croix"<<endl;
cout<<"  7: triangle isocele"<<endl;
cin>>type;
g.set_type(type);

f.ouvrir_graphique();
                  
            
    switch(g.type){

   
	case 1:
	cout<<"donner la longueur de la droite horizontale"<<endl;
	cin>>longueur;
	g.set_droite(x,y,couleur,longueur,0);

	g.dessiner();
	getch();
	g.deplacer(x+100,y+100);
	getch();
   
    
   break;
  
    case 2:
   	cout<<"donner la hauteur de la droite verticale"<<endl;
   	cin>>hauteur;
   	g.set_droite(x,y,couleur,0,hauteur);
   	
   	g.dessiner();
   	getch();
   		g.deplacer(x+100,y+100);
	getch();
   	
   	break;
   	case 3:
   		
   	cout<<"donner la longueur de la droite inclinee"<<endl;
   	cin>>longueur;
   	cout<<"donner la hauteur de la droite inclinee"<<endl;
   	cin>>hauteur;
   	g.set_droite(x,y,couleur,longueur,hauteur);
   
   	g.dessiner();
   	getch();
   		g.deplacer(x+100,y+100);
	getch();
   	break;
   	
   	case 4:
   		cout<<"donner le diametre du cercle"<<endl;
   		cin>>longueur;
   		g.set_cercle(x,y,couleur,longueur);
   	
   	g.dessiner();
   	getch();
   		g.deplacer(x+100,y+100);
	getch();
      break;
      
      case 5:
      	cout<<"donner la longueur du rectangle"<<endl;
      	cin>>longueur;
      	cout<<"donner la hauteur du rectangle"<<endl;
      	cin>>hauteur;
      	g.set_rectangle(x,y,couleur,longueur,hauteur);
      		
   	g.dessiner();
   	getch();
   		g.deplacer(x+100,y+100);
	getch();
      break;
      case 6:
      		cout<<"donner la longueur du croix"<<endl;
      	cin>>longueur;
      	cout<<"donner la hauteur du croix"<<endl;
      	cin>>hauteur;
      	g.set_croix(x,y,couleur,longueur,hauteur);
      	
      	
   	g.dessiner();
   	getch();
   	g.deplacer(x+100,y+100);
	getch();
      break;
      case 7:
      		cout<<"donner la longueur du triangle"<<endl;
      	cin>>longueur;
      	cout<<"donner la hauteur du triangle"<<endl;
      	cin>>hauteur;
            g.set_triangle(x,y,couleur,longueur,hauteur);
			  
      	
   	g.dessiner();
   	getch();
  	g.deplacer(x+100,y+100);
	getch();
      break;    	
	}



cleardevice();



bonHomme.set_dessin(700,250,50,200,80,100,120);

getch();
cleardevice();
bonHomme.transporter(700,250,50,200,80,100,120,(int)couleur,-150,-150);


getch();
cleardevice();
bonHomme.deplacer_dessin(700,300,20,100,25,30,30);
getch();
bonHomme.deplacer_carre(550,350,20,100,25,30,30);
getch();
bonHomme.deplacer_triangle(550,350,20,100,25,30,30);


}
 

