#include "Fenetres.h"
#include <conio.h>
#include<iostream>
#include<graphics.h>
using namespace std;

 void Fenetres::ouvrir_graphique(void){
      	int gd= DETECT,gm;
      	initgraph(&gd, &gm, "");
      //	initwindow(getmaxwidth( ), getmaxheight( ));
	  }
	   
	    
	 
	  
	  int Fenetres::get_couleur_fond(void){
	  	return getbkcolor();
	  } 
	  
	  int Fenetres::get_x_max(void){
	  	return getmaxx();
	  } 
      
      int Fenetres::get_y_max(void){
      	return getmaxy();
	  }
	  int Fenetres::get_couleur(int x, int y){
	  	return getpixel(x,y);
	  }
	  void Fenetres::allume(int x, int y ,int couleur){
	  	putpixel(x,y,couleur);
       }
	  
	  void fermer_graphique(void){
	  	closegraph();
	  }
	  
