#ifndef FIGURE_H 
#define FIGURE_H
#include<graphics.h>
#include <iostream>
using namespace std;
 class Figure{
   	
  	
  public:
  	int type,x,y,longueur,hauteur,couleur;
  public:
  	
  	void set_droite(int x, int y, int couleur, int longeur, int hauteur);//initialise une droite
	
	
	
	void set_cercle(int x, int y, int couleur, int diametre);//initialise un cercle
 	
	
	
	void set_croix(int x, int y, int couleur, int longueur, int hauteur);//initialise un croix
	

	void set_rectangle(int x, int y, int couleur, int longueur, int hauteur);//initialise un rectangle
	
	
	
	
	void set_triangle(int x, int y, int couleur, int longueur , int hauteur);//initialise un triangle
	
	
	int get_couleur();//retourne la couleur de la figure
	int get_x_centre();// retourne l'abscisse du centre de la figure
	
	int get_y_centre();//retourne l'ordonnee du centre de la figure
	
	int get_x_max();//retourne l'abscisse maximal de la figure
	int get_y_max();//retourne l'ordonne maximal de la figure
	int get_x_min();//retourne l'abscisse minimal de la figure
	int get_y_min();//retourne l'ordonnee minimal de la figure
	
	void set_type(int i);//determine le type de la figure
	void dessiner();//dessine la figure 
	
	
	void deplacer(int x, int y);//deplace le centre de la figure vers (x,y)
	
	
	};
	
	
	#endif
