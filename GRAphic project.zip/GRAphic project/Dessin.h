#include "Figure.h"
#include<graphics.h>
#include <iostream>

using namespace std;
class Dessin{
	public :
	int nbrefigure;
	Figure tab[100];
	
	
	
   
	void transporter(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg,int couleur,int dx, int dy);// deplacer le bonhomme 
	
	void set_dessin(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg);//dessiner le bonhomme

	void deplacer_dessin(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg);//deplacer le bonhomme dans un trajet circulaire
	
	void deplacer_carre(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg);//deplacer le bonhomme dans un trajet carre

    void deplacer_triangle(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg);//deplacer le bonhomme dans un trajet triangulaire

  
  
  
};
